<section id="featured-services" class="featured-services">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Lini Bisnis</h2>          
    </div>
  </div>
  <div class="about-us-wrapper">
                <div class="container"data-aos="fade-up">
                    <div class="row">
                        <!-- About Text Start -->
                        <div class="col-lg-6 order-last order-lg-first">
                            <div class="about-text-wrap">
                                <h2><span>Gerak</span>dan Fokus</h2>
                                <p>We provide the best Beard oile all over the world. We are the worldd best store in indi for Beard Oil. You can buy our product without any hegitation because they truste us and buy our product without any hagitation because they belive and always happy buy our product.</p>
                                <p>Some of our customer say’s that they trust us and buy our product without any hagitation because they belive us and always happy to buy our product.</p>
                                <p>We provide the beshat they trusted us and buy our product without any hagitation because they belive us and always happy to buy.</p>
                            </div>
                        </div>
                        <!-- About Text End -->
                        <!-- About Image Start -->
                        <div class="col-lg-5 col-md-10">
                            <div class="about-image-wrap">
                                <img class="img-full" src="<?php echo base_url('/asset/web-loka/');?>images/product/large-size/13.jpg" alt="About Us" />
                            </div>
                        </div>
                        <!-- About Image End -->
                    </div>
                </div>
            <!-- </div>
</section> -->

<!-- ======= Featured Services Section ======= -->
<!-- <section id="featured-services" class="featured-services"> -->
    <div class="container">

      <div class="row gy-4">


        <div class="col-xl-4 col-md-6 d-flex" data-aos="zoom-out" data-aos-delay="200">
          <div class="service-item position-relative">
            <div class="icon d-flex justify-content-center"><i class="fa fa-ship"></i></div>
            <h4>Distribution</h4>
            <p class="text-justify">PT. Jhonlin Agro Raya selalu
              mengedapankan
              pengembangan berbasiskan
              penelitian yang mendalam, untuk
              kesinambungan dan kwalitas
              produksi perusahaan.</p>
              <a class="read-more" href="<?php echo base_url();?>Lini_Bisnis/Distribution">Read More...</a>
          </div>
        </div><!-- End Service Item -->

        <div class="col-xl-4 col-md-6 d-flex" data-aos="zoom-out" data-aos-delay="400">
          <div class="service-item position-relative">
            <div class="icon d-flex justify-content-center"><i class="fa fa-globe"></i></div>
            <h4>Sistem Integrated</h4>
            <p class="text-justify">Membangun hubungan yang
              kuat dan saling
              menguntungkan mulai dari
              stake-holder, internal
              perusahaan dan lingkungan
              sosial-masyarakat</p>
              <a class="read-more" href="<?php echo base_url();?>Lini_Bisnis/Distribution">Read More...</a>
          </div>
        </div><!-- End Service Item -->

        <div class="col-xl-4 col-md-6 d-flex" data-aos="zoom-out" data-aos-delay="600">
          <div class="service-item position-relative">
            <div class="icon d-flex justify-content-center"><i class="fa fa-handshake-o"></i></div>
            <h4>Service</h4>
            <p class="text-justify">Menumbuhkan kepercayaan
              klien terhadap pelayanan dan
              hasil produksi yang dihasilkan,
              menjadikan target
              perkembangan klien semakin
              meningkat dari tahun ke tahun.</p>
              <a class="read-more" href="<?php echo base_url();?>Lini_Bisnis/Distribution">Read More...</a>
          </div>
        </div><!-- End Service Item -->

      </div>

    </div>
  </div>
  </section><!-- End Featured Services Section -->